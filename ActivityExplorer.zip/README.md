# Activity Explorer — starter

Starter Android/Kotlin: bolha flutuante, consulta inicial de Activities, relatório da árvore acessível e dependências Shizuku.

## Build recomendado pelo celular
1. Envie a pasta a um repositório GitHub.
2. Abra **Actions** e execute **Build APK**.
3. Baixe o artefato `ActivityExplorer-debug` da execução concluída.

## Build com Termux
É possível, mas exige JDK 17, Gradle e Android SDK/Build Tools configurados. Pelo celular, GitHub Actions normalmente é mais simples.

## Teste
1. Instale `app-debug.apk`.
2. Conceda a permissão de sobreposição.
3. Em Configurações > Acessibilidade, ative Activity Explorer.
4. Volte ao app, inicie a bolha e abra outro app para testar.

## Limitações desta versão
- Shizuku está integrado como dependência e tem uma verificação básica; ainda não há execução de comandos privilegiados.
- A descoberta de Activities depende das restrições de visibilidade do Android.
- Activities não exportadas geralmente não podem ser iniciadas por outro app.
- O serviço de acessibilidade deve ser habilitado manualmente e só lê os elementos que o app alvo expõe à árvore de acessibilidade.
- Use somente em apps e dispositivos que você tem autorização para analisar.
