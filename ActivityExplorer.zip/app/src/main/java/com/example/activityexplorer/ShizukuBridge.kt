package com.example.activityexplorer

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuBridge {
    fun isAvailable(): Boolean = try { Shizuku.pingBinder() } catch (_: Exception) { false }
    fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Exception) { false }
}
