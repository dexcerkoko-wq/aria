package com.example.activityexplorer

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

object ActivityInspector {
    @Suppress("DEPRECATION")
    fun listActivities(context: Context, packageName: String): List<String> = try {
        val pm = context.packageManager
        val info = if (Build.VERSION.SDK_INT >= 33) {
            pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(PackageManager.GET_ACTIVITIES.toLong()))
        } else {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES)
        }
        info.activities?.map { "${it.name}  [${if (it.exported) "exported" else "internal"}]" }
            ?: listOf("Nenhuma Activity listada.")
    } catch (e: Exception) {
        listOf("Não foi possível consultar: ${e.javaClass.simpleName}: ${e.message}")
    }
}
