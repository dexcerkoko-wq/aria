package com.example.activityexplorer

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: LinearLayout? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        showBubble()
    }

    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 180 }

    private fun showBubble() {
        val b = Button(this).apply {
            text = "AE"
            setOnClickListener { if (panel == null) showPanel() else closePanel() }
            setOnTouchListener(object : View.OnTouchListener {
                var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    val lp = v.layoutParams as WindowManager.LayoutParams
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { dx=e.rawX; dy=e.rawY; sx=lp.x; sy=lp.y; return false }
                        MotionEvent.ACTION_MOVE -> {
                            lp.x=sx+(e.rawX-dx).toInt(); lp.y=sy+(e.rawY-dy).toInt()
                            wm.updateViewLayout(v, lp); return true
                        }
                    }
                    return false
                }
            })
        }
        bubble = b
        wm.addView(b, params(64, 56))
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(0xEE20242B.toInt())
        }
        box.addView(TextView(this).apply { text="Activity Explorer"; textSize=18f; setTextColor(-1) })
        box.addView(Button(this).apply {
            text="Analisar tela atual"
            setOnClickListener { showReport(ScreenInspector.lastReport) }
        })
        box.addView(Button(this).apply {
            text="Listar Activities do app atual"
            setOnClickListener {
                val pkg = ScreenInspector.foregroundPackage
                if (pkg == null) showReport("App atual não identificado. Ative a acessibilidade.")
                else showReport("Pacote: $pkg\n\n" + ActivityInspector.listActivities(this@FloatingService, pkg).joinToString("\n"))
            }
        })
        box.addView(Button(this).apply {
            text="Voltar"
            setOnClickListener {
                Toast.makeText(this@FloatingService, "Use o botão Voltar do Android para retornar com segurança.", Toast.LENGTH_LONG).show()
            }
        })
        box.addView(Button(this).apply { text="Fechar painel"; setOnClickListener { closePanel() } })
        panel = box
        wm.addView(box, params(310, WindowManager.LayoutParams.WRAP_CONTENT).apply {
            x=90; y=180; flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        })
    }

    private fun showReport(report: String) {
        val box = panel ?: return
        val scroll = ScrollView(this)
        scroll.addView(TextView(this).apply {
            text=report.ifBlank { "Ainda não há relatório. Ative o serviço de acessibilidade." }
            textSize=13f; setTextColor(-1); setPadding(4,8,4,8)
        })
        box.addView(scroll, 0)
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel=null
    }
    override fun onDestroy() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble=null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
