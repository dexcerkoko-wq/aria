package com.example.activityexplorer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        layout.addView(TextView(this).apply {
            text = "Activity Explorer\n\n1. Conceda sobreposição.\n2. Ative o serviço de acessibilidade.\n3. Inicie o menu flutuante."
            textSize = 18f
        })
        layout.addView(Button(this).apply {
            text = "Permitir sobreposição"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity))
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                else Toast.makeText(this@MainActivity, "Permissão já concedida", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(Button(this).apply {
            text = "Ativar análise de tela"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "Iniciar menu flutuante"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity))
                    Toast.makeText(this@MainActivity, "Conceda sobreposição primeiro", Toast.LENGTH_LONG).show()
                else startService(Intent(this@MainActivity, FloatingService::class.java))
            }
        })
        setContentView(layout)
    }
}
