package com.example.activityexplorer

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ScreenInspector : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        event.packageName?.toString()?.let { foregroundPackage = it }
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            lastReport = buildReport()
        }
    }

    private fun buildReport(): String {
        val root = rootInActiveWindow ?: return "Janela ativa indisponível."
        val out = StringBuilder("Pacote: ${root.packageName}\nElementos encontrados:\n")
        var count = 0
        fun visit(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || count >= 120) return
            val text = node.text?.toString()?.take(100).orEmpty()
            val desc = node.contentDescription?.toString()?.take(100).orEmpty()
            val id = node.viewIdResourceName.orEmpty()
            if (text.isNotBlank() || desc.isNotBlank() || id.isNotBlank() || node.isClickable) {
                out.append("  ".repeat(depth.coerceAtMost(8)))
                out.append(text.ifBlank { desc })
                if (id.isNotBlank()) out.append(" [").append(id).append("]")
                if (node.isClickable) out.append(" [clicável]")
                out.append("\n")
                count++
            }
            for (i in 0 until node.childCount) visit(node.getChild(i), depth + 1)
        }
        visit(root, 0)
        root.recycle()
        return out.toString()
    }

    override fun onInterrupt() {}

    companion object {
        @Volatile var foregroundPackage: String? = null
        @Volatile var lastReport: String = "Aguardando eventos de acessibilidade."
    }
}
